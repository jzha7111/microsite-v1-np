$(document).ready(function () {
	$('.input-group-password').click(function () {
		if($('.form-control-password').attr('type') == 'text'){
			$('.form-control-password').attr('type', 'password');
			$('.input-group-password').removeClass('active');	
		}
		else {
			$('.form-control-password').attr('type', 'text');
			$('.input-group-password').addClass('active');
			
		}
	});
});

function handleMessage(event) {
	var accepted_origin = 'http://localhost:4200';
	if (event.origin == accepted_origin) {
		if (event.data['task'] == 'scroll_top') {
			window.scrollTo(0, 0);
		}
		// you can have more tasks
	} else {
		console.error('Unknown origin', event.origin);
	}
}

window.onload = function () {
	window.addEventListener("message", handleMessage, false);
}
