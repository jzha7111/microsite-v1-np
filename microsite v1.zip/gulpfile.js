const { src, dest, parallel, series, watch } = require('gulp');
const sass = require('gulp-sass');
const prefix = require('gulp-autoprefixer');
const data = require('gulp-data');
const sourcemaps = require('gulp-sourcemaps');
const concat = require('gulp-concat');
const plumber = require('gulp-plumber');
const browsersync = require('browser-sync');
const gulpcopy = require('gulp-copy');
const del = require('del');
const path = require('path');
var cleanCSS = require('gulp-clean-css');
var minify = require('gulp-minify');
var concatCss = require('gulp-concat-css');

var config = {
	scss: 'css',
	js: 'js',
	jqueryDir: './node_modules/jquery',
	toastrDir: './node_modules/toastr',
	bootstrapDir: './node_modules/bootstrap',
	publicDir: './public',
	webappDir: '../web-app/nexpay/src',
	portalDir: 'C:\\work\\work\\NexPay\\repo\\NexPay.Portal\\NexPay.Portal.Mvc5UI\\Content',
};

// SCSS bundled into CSS task
function microCss() {
	return src('css/micro.scss')
		.pipe(sourcemaps.init())
		// Stay live and reload on error
		.pipe(plumber({
			handleError: function (err) {
				console.log(err);
				this.emit('end');
			}
		}))
		.pipe(sass({
			includePaths: [config.bootstrapDir + '/scss'],
			errLogToConsole: true,
			//outputStyle: 'compressed'
		}).on('error', function (err) {
			console.log(err.message);
			// sass.logError
			this.emit('end');
		}))
		.pipe(prefix(['last 15 versions', '> 1%', 'ie 8', 'ie 7', 'iOS >= 9', 'Safari >= 9', 'Android >= 4.4', 'Opera >= 30'], {
			cascade: true
		}))
		.pipe(concat('micro.css'))
		.pipe(sourcemaps.write('.'))
		.pipe(dest(config.publicDir + '/css'))
		.pipe(dest(config.webappDir + '/css'));
}


function contentCss() {
	return src('css/content.scss')
		.pipe(sourcemaps.init())
		// Stay live and reload on error
		.pipe(plumber({
			handleError: function (err) {
				console.log(err);
				this.emit('end');
			}
		}))
		.pipe(sass({
			includePaths: [config.bootstrapDir + '/scss'],
			errLogToConsole: true,
			//outputStyle: 'compressed'
		}).on('error', function (err) {
			console.log(err.message);
			// sass.logError
			this.emit('end');
		}))
		.pipe(prefix(['last 15 versions', '> 1%', 'ie 8', 'ie 7', 'iOS >= 9', 'Safari >= 9', 'Android >= 4.4', 'Opera >= 30'], {
			cascade: true
		}))
		.pipe(concat('content.css'))
		.pipe(sourcemaps.write('.'))
		.pipe(dest(config.publicDir + '/css'))
		.pipe(dest(config.webappDir + '/css'));
}

function insuranceCss() {
	return src('css/insurance.scss')
		.pipe(sourcemaps.init())
		// Stay live and reload on error
		.pipe(plumber({
			handleError: function (err) {
				console.log(err);
				this.emit('end');
			}
		}))
		.pipe(sass({
			includePaths: [config.bootstrapDir + '/scss'],
			errLogToConsole: true,
			//outputStyle: 'compressed'
		}).on('error', function (err) {
			console.log(err.message);
			// sass.logError
			this.emit('end');
		}))
		.pipe(prefix(['last 15 versions', '> 1%', 'ie 8', 'ie 7', 'iOS >= 9', 'Safari >= 9', 'Android >= 4.4', 'Opera >= 30'], {
			cascade: true
		}))
		.pipe(concat('insurance.css'))
		.pipe(sourcemaps.write('.'))
		.pipe(dest(config.publicDir + '/css'))
		.pipe(dest(config.webappDir + '/css'));
}

function css() {
	return src(['./css/app.scss', config.toastrDir + '/toastr.scss'])
		.pipe(sourcemaps.init())
		// Stay live and reload on error
		.pipe(plumber({
			handleError: function (err) {
				console.log(err);
				this.emit('end');
			}
		}))
		.pipe(sass({
			includePaths: [config.bootstrapDir + '/scss'],
			errLogToConsole: true,
			//outputStyle: 'compressed'
		}).on('error', function (err) {
			console.log(err.message);
			// sass.logError
			this.emit('end');
		}))
		.pipe(prefix(['last 15 versions', '> 1%', 'ie 8', 'ie 7', 'iOS >= 9', 'Safari >= 9', 'Android >= 4.4', 'Opera >= 30'], {
			cascade: true
		}))
		.pipe(concat('app.css'))
		.pipe(sourcemaps.write('.'))
		.pipe(dest(config.publicDir + '/css'))
		.pipe(dest(config.webappDir + '/css'));
}

// JS bundled into min.js task
function js() {
	return src([config.jqueryDir + '/dist/jquery.js', config.bootstrapDir + '/dist/js/bootstrap.bundle.js', config.toastrDir + '/toastr.js', './js/*.js'])
		.pipe(sourcemaps.init())
		.pipe(concat('app.js'))
		.pipe(sourcemaps.write('.'))
		.pipe(dest(config.publicDir + '/js'));
}

/**
 * Copy assets directory
 */

function copyFonts() {
	// Copy fonts
	return src([config.bootstrapDir + '/assets/fonts/**/*'])
		.pipe(gulpcopy(config.publicDir + '/assets/fonts', { prefix: 2 }));
}

function copyAssets() {
	// Copy assets
	return src([config.publicDir + '/assets/**/*']
	).pipe(gulpcopy(config.webappDir + '/assets', { prefix: 2 }));

}

// BrowserSync
function browserSync() {
	browsersync({
		server: {
			baseDir: config.publicDir,
			index: "microsite.html"
		},
		notify: false,
	});
}

// BrowserSync reload 
function browserReload() {
	return browsersync.reload;
}

// Watch files
function watchFiles() {
	// Watch SCSS changes    
	watch(config.scss + '/**/*.scss', parallel(css, contentCss, insuranceCss, microCss))
		.on('change', browserReload());
	// Watch javascripts changes    
	watch(config.js + '/*.js', parallel(js))
		.on('change', browserReload());
	// Assets Watch and copy to build in some file changes
	watch(config.publicDir + '/assets/**/*')
		.on('change', series(copyFonts, copyAssets, css, contentCss, insuranceCss, microCss, js, browserReload()));
	watch(config.publicDir + '/**/*.html')
		.on('change', browserReload());
}

const watching = parallel(copyFonts, copyAssets, css, contentCss, insuranceCss, microCss, js, watchFiles, browserSync);

exports.js = js;
exports.contentCss = contentCss;
exports.insuranceCss = insuranceCss;
exports.microCss = microCss;
exports.default = parallel(copyFonts, copyAssets, css, contentCss, insuranceCss, microCss, js);
exports.watch = watching;

